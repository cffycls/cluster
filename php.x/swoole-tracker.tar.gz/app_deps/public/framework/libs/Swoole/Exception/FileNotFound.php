<?php
namespace Swoole\Exception;

class FileNotFound extends \Exception
{

}