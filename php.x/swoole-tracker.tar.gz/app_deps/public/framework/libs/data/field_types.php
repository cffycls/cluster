<?php
$field_types['varchar'] = array('name' => '单行文本', 'fieldtype' => 'varchar');
$field_types['text'] = array('name' => '多行文本', 'fieldtype' => 'text');
$field_types['htmltext'] = array('name' => 'HTML文本', 'fieldtype' => 'MEDIUMBLOB');
$field_types['image'] = array('name' => '图片', 'fieldtype' => 'varchar');
$field_types['path'] = array('name' => '路径', 'fieldtype' => 'varchar');
$field_types['url'] = array('name' => '地址', 'fieldtype' => 'varchar');
$field_types['radio'] = array('name' => '单选', 'fieldtype' => 'varchar');
$field_types['checkbox'] = array('name' => '复选', 'fieldtype' => 'varchar');
