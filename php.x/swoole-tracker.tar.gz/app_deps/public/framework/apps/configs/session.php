<?php
return array(
    //cache.php配置中必须有session一项
    'cache_id' => 'session',
    'use_php_session' => false,
    'session_lifetime' => 0,
    //'cookie_domain' => 'framework.com',
    'cookie_lifetime' => 86400000,
);
