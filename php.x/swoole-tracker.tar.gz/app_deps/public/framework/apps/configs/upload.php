<?php
$upload = array(
    'base_dir' => WEBPATH.'/uploads/',
    'base_url' => WEBROOT.'/uploads/',
);
return $upload;