<?php
return array(
    'handlers' => array(
        App\Handler\Hello1::class,
        App\Handler\Hello2::class,
    ),
);