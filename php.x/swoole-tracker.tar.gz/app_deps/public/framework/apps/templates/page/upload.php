<form enctype="multipart/form-data" action="" method="POST">
    Select File: <input name="Filedata" type="file"/>
    <input type="submit" value="Upload File"/>
</form>