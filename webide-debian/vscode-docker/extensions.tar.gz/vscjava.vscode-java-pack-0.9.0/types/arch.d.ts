export = arch;
declare function arch(): string;
